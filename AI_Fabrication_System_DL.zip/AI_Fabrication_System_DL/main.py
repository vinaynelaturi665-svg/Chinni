
from visual_module import VisualAnalyzer
from physiological_module import PhysiologicalAnalyzer
from decision_engine import DecisionEngine
from fabrication_output import FabricationSystem
import time

visual = VisualAnalyzer()
physio = PhysiologicalAnalyzer()
engine = DecisionEngine()
fabricator = FabricationSystem()

print("Deep Learning AI Fabrication System Started")

while True:
    img = visual.get_visual_features()
    phy = physio.get_physiological_features()

    if img is not None:
        decision = engine.predict(img, phy)
        print(fabricator.fabricate(decision))

    time.sleep(2)
