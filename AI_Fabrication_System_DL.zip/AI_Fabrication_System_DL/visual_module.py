
import cv2
import numpy as np

class VisualAnalyzer:
    def get_visual_features(self):
        cap = cv2.VideoCapture(0)
        ret, frame = cap.read()
        cap.release()

        if not ret:
            return None

        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        resized = cv2.resize(gray, (64,64))
        return resized.reshape(64,64,1)/255.0
