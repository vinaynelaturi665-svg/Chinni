
import numpy as np
from cnn_model import create_cnn

class DecisionEngine:
    def __init__(self):
        self.model = create_cnn()

    def predict(self, image, physio):
        image = image.reshape(1,64,64,1)
        prediction = self.model.predict(image)
        return int(np.argmax(prediction))
