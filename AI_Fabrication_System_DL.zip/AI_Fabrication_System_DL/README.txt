
AI-Based Future Fabrication System (Deep Learning)

Requirements:
pip install tensorflow opencv-python pyserial numpy

Steps:
1. Upload arduino_sensor.ino to Arduino
2. Connect Arduino via USB
3. Update COM port in physiological_module.py
4. Run python main.py
