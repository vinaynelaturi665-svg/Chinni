
class FabricationSystem:
    def fabricate(self, decision):
        mapping = {
            0: "Soft wearable fabric",
            1: "Rigid assistive structure",
            2: "Smart adaptive material"
        }
        return mapping.get(decision, "Unknown output")
