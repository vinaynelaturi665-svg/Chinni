
import serial
import numpy as np

class PhysiologicalAnalyzer:
    def __init__(self, port='COM3', baud=9600):
        self.ser = serial.Serial(port, baud)

    def get_physiological_features(self):
        line = self.ser.readline().decode().strip()
        hr, temp, stress = line.split(',')
        return np.array([float(hr), float(temp), float(stress)])
