
import skfuzzy as fuzz
import numpy as np

def fuzzy_decision(temp, stress):
    x = np.arange(0, 101, 1)
    temp_low = fuzz.trimf(x, [0, 0, 50])
    temp_high = fuzz.trimf(x, [50, 100, 100])
    return 'Adaptive' if temp > 50 else 'Standard'
